##### Detailed Information about _Service End Points_ section

This section contains all services urls use by the viewer. To show them, check the _show advanced configuration options_
check box. They are read only values so it is not possible to modify them directly. If you have problems with those services,
please contact the website administrator.
