##### Informations détaillées concernant la section _lien pour les services_

Cette section contient toutes les URL des services utilisées par le visualisateur. Pour les afficher, cochez la case
_Afficher les options de configuration avancées_. Ce sont des valeurs en lecture seule, il n'est donc pas possible de les
modifier directement. Si vous avez des problèmes avec ces services, veuillez contacter l'administrateur du site.
